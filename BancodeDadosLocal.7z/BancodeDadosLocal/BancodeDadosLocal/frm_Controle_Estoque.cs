﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BancodeDadosLocal
{
    public partial class frm_Controle_Estoque : Form
    {
        public frm_Controle_Estoque()
        {
            frm_Tela_Carregamento frmLoadscreen = new frm_Tela_Carregamento();
            frmLoadscreen.Show();
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            frm_Saindo frmSaindo = new frm_Saindo();
            frmSaindo.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            this.ShowInTaskbar = false;
            timer2.Start();
            exibirDados();
        }
        
        private void exibirDados()
        {
            DAL _dal = new DAL();
            dgvProdutos.DataSource = _dal.Load("Select * from Produtos");
        }

        private void dgvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvProdutos.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            {
                txtId.Text = dgvProdutos.Rows[e.RowIndex].Cells[0].Value.ToString();
                txtNome.Text = dgvProdutos.Rows[e.RowIndex].Cells[1].Value.ToString();
                txtEstoque.Text = dgvProdutos.Rows[e.RowIndex].Cells[2].Value.ToString();
                txtCusto.Text = dgvProdutos.Rows[e.RowIndex].Cells[3].Value.ToString();
                txtDescricao.Text = dgvProdutos.Rows[e.RowIndex].Cells[4].Value.ToString();
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                DAL _dal = new DAL();
                int codigo = Convert.ToInt32(txtId.Text);
                string sql = "Select * from Produtos Where Id=" + codigo;
                DataTable dtProdutos = new DataTable();
                dtProdutos = _dal.Load(sql);
                txtId.Text = dtProdutos.Rows[0][0].ToString();
                txtNome.Text = dtProdutos.Rows[0][1].ToString();
                txtEstoque.Text = dtProdutos.Rows[0][2].ToString();
                txtCusto.Text = dtProdutos.Rows[0][3].ToString();
                txtDescricao.Text = dtProdutos.Rows[0][4].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            try
            {
                DAL _dal = new DAL();
                Produto prod = new Produto();
                prod.nome = txtNome.Text;
                prod.estoque = Convert.ToInt32(txtEstoque.Text);
                prod.custo = Convert.ToDecimal(txtCusto.Text);
                prod.descricao = txtDescricao.Text;
                _dal.Insert(prod, "Insert Into Produtos(Nome,Estoque,Custo,Descricao) values(@nome,@estq,@cust,@desc)");
                exibirDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            try
            {
                DAL _dal = new DAL();
                Produto prod = new Produto();
                prod.Id = Convert.ToInt32(txtId.Text);
                prod.nome = txtNome.Text;
                prod.estoque = Convert.ToInt32(txtEstoque.Text);
                prod.custo = Convert.ToDecimal(txtCusto.Text);
                prod.descricao = txtDescricao.Text;
                _dal.Update(prod, "Update Produtos set Nome=@nome, Estoque=@estq , Custo=@cust ,Descricao=@desc Where Id=@codigo");
                exibirDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                DAL _dal = new DAL();
                int codigo = Convert.ToInt32(txtId.Text);
                _dal.Delete(codigo, "Delete from Produtos where Id=@codigo");
                exibirDados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public static void LimparTextBox(Control parent)
        {
            foreach (Control c in parent.Controls)
            {
                if (c.GetType() == typeof(TextBox))
                {
                    ((TextBox)(c)).Text = string.Empty;
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            LimparTextBox(this);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            this.ShowInTaskbar = true;
            this.Show();
            this.WindowState = FormWindowState.Normal;
            timer2.Stop();
        }

    }
}
