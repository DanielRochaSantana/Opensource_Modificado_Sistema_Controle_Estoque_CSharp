﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace BancodeDadosLocal
{
    public partial class frm_Saindo : Form
    {
        public frm_Saindo()
        {
            InitializeComponent();
        }

        private void frm_Saindo_Load(object sender, EventArgs e)
        {
            timer3.Start();            
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Stop();
            Application.Exit();
        }
    }
}
