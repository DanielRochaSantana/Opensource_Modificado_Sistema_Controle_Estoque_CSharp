﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BancodeDadosLocal
{
    public class Produto
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public int estoque { get; set; }
        public decimal custo { get; set; }
        public string descricao { get; set; }
    }
}
